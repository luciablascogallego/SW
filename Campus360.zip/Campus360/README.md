# LEEME #
Se han implementado unicamente las dos primeras funcionalidades, gestion de recursos y la gestion de recursos en un curso. Tambien se ha incluido CSS.
